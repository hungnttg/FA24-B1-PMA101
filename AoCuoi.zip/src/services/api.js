import axios from "axios";
const API_BASE_URL='http://localhost:5001/api';
//ham login
export const loginUser = async (username,password)=>{
    try {
        const API_URL = `${API_BASE_URL}/users/login`;
        const response = await axios.post(API_URL,{username,password});
        console.log("ket qua dang nhap: "+response.data);
        return response.data;
    } catch (error) {
        throw new Error(error);
    }
};
//ham goi API de lay danh sach ao cuoi
export const fetchWeddingDresses = async () =>{
    try {
        const response= await axios.get(`${API_BASE_URL}/weddingDresses`);
        return response.data;
    } catch (error) {
        console.error("error: ",error);
        throw error;
    }
};
