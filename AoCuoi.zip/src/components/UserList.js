import React,{useEffect,useState} from "react";
import { Text,View,FlatList,StyleSheet } from "react-native";
import axios from "axios";
const UserList = () =>{
    //code
    const [users,setUsers]=useState([]);
    useEffect(()=>{
        const fetchUser = async () =>{
            try {
                const response = await axios.get('http://localhost:5001/api/users');
                setUsers(response.data);
            } catch (error) {
                throw error;
            }
        };
        fetchUser();
    },[]);
    //giao dienj
    return(
        <View style={styles.container}>
            <FlatList
                data={users}
                keyExtractor={(item)=>item._id}
                renderItem={({item})=>(
                    <View style={styles.item}>
                        <Text style={styles.username}>{item.username}</Text>
                    </View>
                )}
            />
        </View>
    );
}
const styles=StyleSheet.create({
    container:{
        flex:1,
        padding:20,
    },
    item:{
        padding:20,
        borderBottomColor:'#ccc',
        borderBottomWidth:1,
    },
    username:{
        fontWeight:'bold',
    },
});
export default UserList;