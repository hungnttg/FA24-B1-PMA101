import React,{useEffect,useState} from "react";
import { Text,View,Button,FlatList,Image,StyleSheet } from "react-native";
import { fetchWeddingDresses } from "../services/api";
const WeddingDressList = () =>{
    //code
    const [dresses,setDresses]=useState([]);
    useEffect(()=>{
        //goi api de tra ve danh sach ao cuoi
        const getDresses = async () =>{
            try {
                const data = await fetchWeddingDresses();
                setDresses(data);
            } catch (error) {
                console.error("Loi: ",error);
            }
        };
        getDresses();
    },[]);
    const renderItem=({item})=>(
        <View style={StyleSheet.item}>
            <Image source={{uri:item.imageUrl}} style={styles.image}/>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.price}>{item.price}</Text>
        </View>
    );
    //giao dien
    return(
        <FlatList
            data={dresses}
            renderItem={renderItem}
            keyExtractor={(item)=>item._id}
        />
    );
};
const styles = StyleSheet.create({
    item:{
        marginBottom:20,
        padding:10,
        borderColor:'#ccc',
        borderWidth:1,
        borderRadius:5,
    },
    image:{
        width:200,
        height:200,
    },
    name:{
        fontSize:20,
        fontWeight:'bold',
    },
    price:{
        fontSize:16,
        color:'#555',
    },
});
export default WeddingDressList;