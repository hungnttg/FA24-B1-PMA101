import React,{useState} from "react";
import { View,Text,Button,TextInput,StyleSheet,Alert } from "react-native";
import axios from "axios";
import { scheduleAppointment } from "../services/api";
const DatLichScreen = ({route,navigation})=>{
    //code
    const {dressId}=route.params;
    const [customerId,setCustomerId]=useState('');
    const [date,setDate]=useState('');
    const [time,setTime]=useState('');
    const handleDatLich= async ()=>{
        try {
            const response=await axios.post('http://localhost:5001/api/appointments',{
                dressId, customerId,date,time,
            });
        } catch (error) {
            
        }
    };

    //giao dien
    return(
        <View style={styles.container}>
            <Text style={styles.title}>Dat lich thu Ao cuoi {dressId}</Text>
            <TextInput style={styles.input}
                value={customerId}
                onChangeText={setCustomerId}
                placeholder="Nhap ma khach hang"
            />
            <TextInput style={styles.input}
                value={date}
                onChangeText={setDate}
                placeholder="Enter Date (YYYY-MM-DD)"
            />
             <TextInput style={styles.input}
                value={time}
                onChangeText={setTime}
                placeholder="Enter Time (HH:MM)"
            />
            <Button title="Dat lich" onPress={handleDatLich}/>
        </View>
    );
};
const styles=StyleSheet.create({
    container: {
        flex:1,
        padding:20,
    },
    title:{
        fontSize:24,
        fontWeight:'bold',
        marginBottom:20,
    },
    input:{
        borderWidth:1,
        borderColor:'#bbb',
        padding:10,
        borderRadius:10,
        marginBottom:10,
    },

});
export default DatLichScreen;