import React from "react";
import { Text,View,Button,StyleSheet } from "react-native";
const DressDetailScreen = ({route,navigation})=>{
    //code
    const {dressId} = route.params;
    const handleDatLich = () =>{
        navigation.navigate('DatLich',{dressId});
    };
    //giao dien
    return(
        <View style={styles.container}>
            <Text style={styles.title}>Dress Detail  - {dressId}</Text>
            <Text style={styles.description}>Chi tiet vay - {dressId}</Text>
            <Button title="Dat lich" onPress={handleDatLich}/>
        </View>
    );
};
const styles=StyleSheet.create({
    container: {
        flex:1,
        padding:20,
    },
    title:{
        fontSize:24,
        fontWeight:'bold',
        marginBottom:20,
    },
    description:{
        fontSize: 16,
    },

});
export default DressDetailScreen;