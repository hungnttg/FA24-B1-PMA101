import React,{useState} from "react";
import { Text,View,Button,TextInput,StyleSheet } from "react-native";
import {loginUser} from '../services/api';
const LoginScreen = ({navigation}) =>{
    //code
    const [username,setUsername]=useState('');
    const [password,setPassword]=useState('');
    const [error,setError]=useState('');

    const handleLogin = async () =>{
        try {
            const response=await loginUser(username,password);
            if(response.role){
                navigation.navigate('Home',{role:response.role});
            }
        } catch (error) {
            setError(error.message);
            console.error("Login that bai: ",error);
        }
        
    };
    //giao dien
    return(
        <View style={styles.container}>
            <Text style={styles.label}>Username:</Text>
            <TextInput
                style={styles.input}
                value={username}
                onChangeText={setUsername}
                placeholder="Nhap username"
            />
            <Text style={styles.label}>Password:</Text>
            <TextInput
                style={styles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="Nhap username"
            />
            {error ? <Text style={styles.error}>{error}</Text> : null}
            <Button title="Login" onPress={handleLogin}/>
        </View>
    );
};
const styles = StyleSheet.create({
    container:{
        flex:1,
        padding:20,
    },
    label:{
        fontSize:16,
        marginBottom:10,
    },
    input:{
        borderWidth:1,
        borderColor:'#bbb',
        padding:10,
        borderRadius:10,
        marginBottom:10,
    },
    error:{
        color:'red',
        marginBottom:10,
    },
});
export default LoginScreen;
