import React,{useEffect,useState} from "react";
import { Text,View,Button,FlatList,Image,StyleSheet } from "react-native";
import { fetchWeddingDresses } from "../services/api";
const HomeScreen = ({navigation}) =>{
    //code
    const [dresses,setDresses]=useState([]);
    const [loading,setLoading]=useState(true);
    useEffect(()=>{
        //goi api de tra ve danh sach ao cuoi
        const getDresses = async () =>{
            try {
                const data = await fetchWeddingDresses();
                setDresses(data);
            } catch (error) {
                console.error("Loi: ",error);
            }
            finally{
                setLoading(false);
            }
        };
        getDresses();
    },[]);
    if(loading){
        return(
            <View style={styles.container}>
                <Text>Loading dresses...</Text>
            </View>
        );
    }
   
    //giao dien
    return(
       <View style={styles.container}>
            <Text style={styles.title}>Wedding dresses</Text>
            <FlatList
                data={dresses}
                keyExtractor={(item)=>item._id}
                renderItem={({item})=>(
                    <Button
                        title={item.name}
                        onPress={()=>navigation.navigate('DressDetail',{dressId:item._id})}
                    />
                )}
            />
       </View>
    );
};
const styles = StyleSheet.create({
    container:{
        flex:1,
        padding:20,
    },
    title:{
        fontSize:25,
        fontWeight:'bold',
        marginBottom:20,
    },
    item:{
        marginBottom:20,
        padding:10,
        borderColor:'#ccc',
        borderWidth:1,
        borderRadius:5,
    },
    image:{
        width:200,
        height:200,
    },
    name:{
        fontSize:20,
        fontWeight:'bold',
    },
    price:{
        fontSize:16,
        color:'#555',
    },
});
export default HomeScreen;